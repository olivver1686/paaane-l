<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db = new SQLite3('./.db.db');
$rows3 = $db->query("SELECT * FROM dns");
$row3 = $rows3->fetchArray();

$portal_one    	= $row3['portal1'];
$portal_two	=     $row3['portal2'];
$portal_three	=   $row3['portal3'];

$rows1 = $db->query("SELECT * FROM dev");
$row1 = $rows1->fetchArray();
$devtitle    	= $row1['Title'];



echo'
{
  "status": true,
  "message": "Success",
  "records": [
  {
     "run_status": "true",
     "status_message": "",
     "services": "live,
   vod,
   series",
     "package": "premium",
     "portal_one": "'.$portal_one.'",
     "portal_two": "'.$portal_two.'",
     "portal_three": "'.$portal_three.'",
     "version_code": "18",
     "force_update": "false",
     "update_link": "",
     "update_message": "",
     "developer_info": "'.$devtitle.'",
     "show_contact_info": "true",
     "multiscreen":"true"
  }
        ]
}';
?>
